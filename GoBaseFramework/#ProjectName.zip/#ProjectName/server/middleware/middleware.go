package middleware

import (
	"#projectname/server/api/modules/common/jwtUtils"
	"strings"

	"corelab.mkcl.org/MKCLOS/coredevelopmentplatform/coreospackage/logginghelper"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

//Init middleware
func Init(e *echo.Echo, o *echo.Group, r *echo.Group, c *echo.Group) {
	e.Use(middleware.GzipWithConfig(middleware.GzipConfig{
		Level: 5,
	}))
	images := e.Group("/images")
	images.Use(middleware.StaticWithConfig(middleware.StaticConfig{
		Root:   "",
		Browse: true,
	}))

	e.Use(middleware.StaticWithConfig(middleware.StaticConfig{
		Root:   "",
		Browse: true,
	}))

	// validate JWT for requests coming from web
	c.Use(validateJWT())

}

func validateJWT() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			device := c.Request().Header.Get("device")
			if device != "mobile" {
				tokenFromRequest := c.Request().Header.Get("authorization")
				if strings.TrimSpace(tokenFromRequest) == "" {
					// logginghelper.LogDebug("error occured while splitting token")
					return echo.ErrUnauthorized
				}
				tokenArray := strings.Split(tokenFromRequest, "Bearer")
				if len(tokenArray) <= 1 {
					// logginghelper.LogDebug("error occured while splitting token")
					return echo.ErrUnauthorized
				}

				tokenFromRequest = strings.Trim(tokenArray[1], " ")
				// check token in gcache
				_, tokenError := jwtUtils.GetDecodedLoginFromToken(c)

				if tokenError != nil {
					logginghelper.LogError("validateJWT: error occured while calling GetDecodedLoginFromToken ", tokenError)
					return echo.ErrUnauthorized
				}
			}
			return next(c)
		}
	}
}
