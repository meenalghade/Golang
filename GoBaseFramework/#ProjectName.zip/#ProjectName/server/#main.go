//go:generate goversioninfo -icon=mkcl.ico
package main

import (
	"fmt"
	"#projectname/server/api"

	"log"

	"corelab.mkcl.org/MKCLOS/coredevelopmentplatform/coreospackage/confighelper"
	"github.com/labstack/echo"
)

var APP_ENV = "dev"
var APP_VERSION string
var APP_ISACTIVATION string

var apicdnServerPort = "4888"

func main() {

	// Start Simple API server
	startServer()
}

func startServer() {

	// dalhelper.SetSecurityRequired(true)
	// Initialzing LazyHelper

	// Starting Server
	e := echo.New()

	confighelper.InitViper()

	// Hiding ECHO banner from terminal
	e.HideBanner = true

	//TODO: @Sachin Add Banner for EMA

	//Bind API
	api.Init(e)
	fmt.Println("starting server on localhost:", apicdnServerPort)
	err := e.Start(":" + apicdnServerPort)

	if err != nil {
		log.Fatal(err)
	}
}
