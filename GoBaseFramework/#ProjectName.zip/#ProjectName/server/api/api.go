package api

//FIXME: can we remove header file line
import (
	// #imports

	"github.com/labstack/echo"
)

//Init api binding
func Init(e *echo.Echo) {

	o := e.Group("/o")
	r := e.Group("/r")
	// r.Use(echoMiddleware.JWTWithConfig(echoMiddleware.JWTConfig{
	// 	Claims:     &model.JwtCustomClaims{},
	// 	SigningKey: []byte(model.JwtKey),
	// }))

	c := r.Group("/c")
	// Bind Middeleware
	// #entries

}
