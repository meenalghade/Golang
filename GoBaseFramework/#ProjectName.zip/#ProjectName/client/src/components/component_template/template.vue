<template>
<div>
</div>
</template>

<script>
import axios from 'axios'
export default {
name:'template',
  components: {
  },
  data() {
    return {
      message : "hello"
    }
  },
  methods: {
  },
   created: function () {
  },
   mounted: function () {
  }
}
</script>

<style>

img {
  width: 30%;
  margin: auto;
  display: block;
  margin-bottom: 10px;
}
</style>
