<template>
  <div id="app">
    <h1></h1>
    
   
    <ul>
      <li><router-link to="/">Home</router-link></li>
      <li><router-link to="/login">Login</router-link></li>
      <li><router-link to="/profile">Profile</router-link></li>
      <li><router-link to="/signup">Sign Up</router-link></li>
      <li><router-link to="/">Blank</router-link></li>
    </ul>


      
  <div>
  <router-view></router-view>
  </div>


  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
    }
  },

  computed:{
    }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
