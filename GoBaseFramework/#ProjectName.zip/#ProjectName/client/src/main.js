import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import axios from 'axios'
Vue.config.productionTip = false
if (process.env.NODE_ENV === 'development') {
    // set baseUrl from app
    axios.defaults.baseURL = 'http://localhost:8080/server/'
    window.serverPath = axios.defaults.baseURL
} else {
    // for prod
    axios.defaults.baseURL = '/'
    window.serverPath = window.location.origin
}
/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: { App }
})