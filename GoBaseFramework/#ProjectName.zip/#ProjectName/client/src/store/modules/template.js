
import * as types from '../mutation-types'
import axios from 'axios'
import router from '../../router'
// initial state
// shape: [{ id, quantity }]
const state = {

}

// getters
const getters = {
  // getters

}

const mutations = {
  //state.Age=data
}
const actions = {
}

export default {
  state,
  getters,
  mutations,
  actions
}
